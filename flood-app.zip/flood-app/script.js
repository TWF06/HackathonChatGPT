// --- CRITICAL CONFIGURATION: REPLACE THIS URL ---
// !!! IMPORTANT !!! Replace 'http://localhost:8000' with your public API URL.
const API_BASE_URL = 'http://localhost:8000'; 
// ----------------------------------------------------

const state = {
    // Language state is fixed to BM for API requests, but the UI is dual-language
    lang: 'bm', 
    vulnerabilities: {},
    location: document.getElementById('user-location')?.value || '', 
};


// ===================================
// 2. OFFLINE FALLBACK CONTENT 
// (The app shows this if the API fails)
// ===================================

function generateOfflineFallback() {
    
    // Hardcoded Dual-Language SOPs
    const steps = [
        'Matikan Suis Utama: Tutup bekalan elektrik utama dan paip gas. (Turn Off Main Switch: Shut off main electrical supply and gas line.)',
        'Pindah ke Tempat Tinggi: Pindah ke tingkat atas rumah atau kawasan yang lebih tinggi. (Move to Higher Ground: Immediately move to the highest floor or a raised area.)',
        'JANGAN Redah Air Banjir: Jangan berjalan, berenang, atau memandu melalui air banjir. (DO NOT Enter Floodwater: Never walk, swim, or drive through floodwater.)',
        'Siapkan Beg Kecemasan: Bawa kit kecemasan anda (dokumen, ubat-ubatan, makanan). (Prepare Emergency Bag: Bring your emergency kit: documents, medicine, food.)',
        'Hubungi Talian Kecemasan: Bomba (994), Polis (999). (Contact Emergency Services: Fire (994), Police (999).)'
    ];

    return `
        <h4 style="color: #dc3545;">🚨 GARIS PANDUAN KECEMASAN (LUAR TALIAN) / EMERGENCY GUIDELINES (OFFLINE MODE)</h4>
        <p><strong>Jika banjir berlaku, sentiasa utamakan keselamatan nyawa. (If a flood occurs, always prioritize saving lives.)</strong></p>
        <h4>Langkah Tindakan (Action Steps):</h4>
        <ol>
            ${steps.map(step => `<li>${step}</li>`).join('')}
        </ol>
    `;
}


// ===================================
// 3. API & CORE LOGIC
// ===================================

async function sendApiRequest(query, endpoint = '/api/query') {
    const outputDiv = document.getElementById('answer-content');
    const spinner = document.getElementById('loading-spinner');
    const offlineBanner = document.getElementById('offline-banner');

    outputDiv.innerHTML = '';
    offlineBanner.classList.add('hidden');
    spinner.classList.remove('hidden');

    const locationData = state.location ? { district: state.location } : null;
    const vulnerabilitiesData = Object.keys(state.vulnerabilities).filter(k => state.vulnerabilities[k]);

    try {
        const payload = {
            user_id: 'anon_hackathon',
            // API request is always sent in BM (Backend will handle translation)
            lang: 'bm', 
            query: query,
            location: locationData,
            vulnerabilities: vulnerabilitiesData, 
        };
        
        const response = await fetch(`${API_BASE_URL}${endpoint}`, {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify(payload)
        });

        if (!response.ok) {
            throw new Error(`API returned status ${response.status}`);
        }

        const data = await response.json(); 
        
        // --- RENDERING LOGIC (Assumes Backend returns Dual Language or BM) ---
        let answerHTML = `
            <h4>Jawapan Ringkas (Quick Answer):</h4>
            <p>${data.answer || "Tiada jawapan terperinci tersedia. Sila rujuk langkah tindakan. / No detailed answer available. Please refer to action steps."}</p>
            
            <h4>Langkah Tindakan (Action Steps):</h4>
            <ol>
                ${(data.steps || []).map(step => `<li>${step}</li>`).join('')}
            </ol>
        `;

        if (data.sources && data.sources.length > 0) {
             answerHTML += `
                <h4>Sumber Rujukan (Sources):</h4>
                <ul>
                    ${data.sources.map(src => `<li><strong>${src.title}</strong> - <a href="${src.link}" target="_blank">Rujuk Sumber / View Source</a></li>`).join('')}
                </ul>
            `;
        }

        outputDiv.innerHTML = answerHTML;

    } catch (error) {
        console.error('API Error: Falling back to offline mode.', error);
        
        offlineBanner.classList.remove('hidden');
        outputDiv.innerHTML = generateOfflineFallback(); // No language parameter needed
    } finally {
        spinner.classList.add('hidden');
    }
}


function generateRegistrationQR() {
    const needs = Object.keys(state.vulnerabilities).filter(k => state.vulnerabilities[k]);
    
    const qrPayload = JSON.stringify({
        jkm_schema_v: 1.0,
        location_input: state.location,
        needs: needs,
        timestamp: new Date().toISOString()
    });

    const canvas = document.getElementById('qrcode-canvas');
    if (!canvas) return;

    QRCode.toCanvas(canvas, qrPayload, function (error) {
        if (error) {
            console.error(error);
            document.getElementById('qr-passport').innerHTML = "<p style='color:red;'>Failed to generate QR code.</p>";
            return;
        }
        document.getElementById('qr-passport').classList.remove('hidden');
    });
}


// ===================================
// 4. EVENT LISTENERS (Simplified)
// ===================================

document.addEventListener('DOMContentLoaded', () => {
    const userLocationInput = document.getElementById('user-location');
    const qrTextElement = document.querySelector('#qr-passport p');
    
    // LANGUAGE TOGGLE LISTENER IS REMOVED
    
    // Vulnerability Toggles
    document.querySelectorAll('.toggle-input').forEach(btn => {
        const key = btn.getAttribute('data-key');
        state.vulnerabilities[key] = false; 

        btn.addEventListener('click', () => {
            btn.classList.toggle('active');
            state.vulnerabilities[key] = btn.classList.contains('active');
            generateRegistrationQR();
        });
    });

    // Location Input Update (QR text update)
    if (userLocationInput && qrTextElement) {
        userLocationInput.addEventListener('input', (e) => {
            const newLocation = e.target.value;
            state.location = newLocation;
            
            // Fixed Dual-Language prompt for QR code text
            qrTextElement.innerHTML = `Pendaftaran untuk lokasi: <strong>${newLocation || 'Lokasi Belum Dimasukkan'}</strong>. (Registration for location: <strong>${newLocation || 'Location Not Entered'}</strong>.) Tunjukkan kod ini untuk pendaftaran pantas di pusat pemindahan (PPS).`;

            generateRegistrationQR();
        });
    }

    // RAG Query Button (Feature C)
    document.getElementById('ask-sop-btn').addEventListener('click', () => {
        const query = document.getElementById('user-query').value;
        if (query.trim()) {
            sendApiRequest(query, '/api/query');
        }
    });

    // Intelligent Routing Button (Feature A)
    document.getElementById('get-shelter-btn').addEventListener('click', () => {
        const needsList = Object.keys(state.vulnerabilities).filter(k => state.vulnerabilities[k]);
        
        // Prompt is sent in BM
        const routingQuery = `Rancang laluan pemindahan yang paling selamat untuk keluarga di ${state.location} dengan keperluan berikut: ${needsList.join(', ')}.`;
        
        sendApiRequest(routingQuery, '/api/query'); 
    });

    // Initial setup
    generateRegistrationQR();
});